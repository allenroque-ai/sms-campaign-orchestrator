#!/bin/bash
cd "$(dirname "$0")"
zip -r ../dist/lambda_promote.zip .